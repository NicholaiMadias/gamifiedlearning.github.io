export const ATLAS_IDS = [
  "gem-electra",
  "gem-maia",
  "gem-taygete",
];

const DEFAULT_SESSION = Object.freeze({
  version: 1,
  boardSize: 7,
  credits: 0,
  launches: 0,
  lastOpenedAt: null,
  selectedAtlas: ATLAS_IDS[0],
});

export function createDefaultSession() {
  return { ...DEFAULT_SESSION };
}

export function normalizeSession(value) {
  return {
    ...createDefaultSession(),
    ...(value && typeof value === "object" ? value : {}),
  };
}

export function markPopupOpened(session, now = new Date().toISOString()) {
  const next = normalizeSession(session);
  return {
    ...next,
    launches: Number(next.launches || 0) + 1,
    lastOpenedAt: now,
  };
}

export function cycleAtlas(session, atlasIds = ATLAS_IDS) {
  const next = normalizeSession(session);
  const currentIndex = Math.max(0, atlasIds.indexOf(next.selectedAtlas));
  const selectedAtlas = atlasIds[(currentIndex + 1) % atlasIds.length];

  return {
    ...next,
    selectedAtlas,
  };
}
