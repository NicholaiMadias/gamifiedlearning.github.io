import { createDefaultSession, normalizeSession } from "./engine/index.js";

const storageArea = globalThis.chrome?.storage?.local ?? null;

function readSession() {
  if (!storageArea) {
    return Promise.resolve(createDefaultSession());
  }

  return new Promise((resolve) => {
    storageArea.get(["matchMakerSession"], (result) => {
      resolve(normalizeSession(result?.matchMakerSession));
    });
  });
}

function writeSession(session) {
  if (!storageArea) {
    return Promise.resolve();
  }

  return new Promise((resolve) => {
    storageArea.set({ matchMakerSession: session }, () => resolve());
  });
}

async function primeSession() {
  await writeSession(await readSession());
}

if (globalThis.chrome?.runtime?.onInstalled) {
  chrome.runtime.onInstalled.addListener(() => {
    void primeSession();
  });
}

if (globalThis.chrome?.runtime?.onMessage) {
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== "match-maker:get-session") {
      return false;
    }

    void readSession().then((session) => {
      sendResponse({ session });
    });

    return true;
  });
}
